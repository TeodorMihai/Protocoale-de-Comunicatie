#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <fcntl.h>

#include "lib.h"

#define HOST "127.0.0.1"
#define PORT 10001

#define simplu  0
#define ack 	1
#define parity  2
#define hamming 3

#define ACK 	1
#define NACK    2

int rec_ack() {

	msg r;

	int res = recv_message(&r);

	if (res < 0) {
		perror("[RECEIVER] Receive error. Exiting.\n");
		return -1;
	}

	if(r.payload[0] == 'A')
		return ACK;

	if(r.payload[0] == 'N')
		return NACK;

	return -1;
}


int send_ack(int x) {

	msg r;

	if(x == ACK) {
		r.len = sprintf(r.payload, "ACK");
		printf("ACK\n");
	}
	else {
		printf("NACK\n");
		r.len = sprintf(r.payload, "NACK");
	}

	if(r.len < 0) {
		perror("[RECEIVER] Error at creating ACK message. Exiting.\n");
		return -1;
	}

	int res = send_message(&r);

	if (res < 0) {
		perror("[RECEIVER] Send ACK error. Exiting.\n");
		return -1;
	}

	return 1;
}



void setBite(char* x, int pos, int val) {

	//seteaza al pos-lea bit (de la stanga la dreapta) al lui x cu valoarea val
	if(val)
		*x = (*x) | (1 << (8 - pos));
	else 
		*x = (*x) & ( 0XFF - (1 << (8 - pos) ) );
	// x = x & (~(1 << (pos - 1) ) );
}

int getBite(int pos, char frst, char scd) {

	//al pos-lea bit din concaternarea frst scd

	if(pos > 8) {
		pos -= 8;
		return ((scd & (1 << (8 - pos))) != 0);
	} else 
		return ((frst & (1 << (8 - pos) ) ) != 0);
}

void changeBite(int pos, char* frst, char* scd) {

	if(pos > 8) {
		pos -= 8;
		*scd = (*scd) ^ ( 1 << (8 - pos) );
	} else 
		*frst = (*frst) ^ (1 << (8 - pos) );
}


void construct_hamming(msg* r) {

	int i;int j;

	int dim = 2 * r->len;

	//construct format


	for( i = r->len - 1; i >= 0 ; --i) {

		char x = r->payload[i];
		char frst = 0;
		char scd = 0;

		setBite(&frst, 7, x & (1 << 7));
		
		int j;

		int nth = 2;

		for( j = 1; j <= 8 ; ++j) {
			
			if(j == 4) continue;
			
			setBite(&scd, j, x & ( 1 << (8 - nth) ) );

			nth++;
		}

		r->payload[dim - 1] = scd;
		r->payload[dim - 2] = frst;

		dim -= 2;
	}

	int k;
	
	//construire mesaj

	for(i = 0; i < 2 * r->len; i += 2) {

		for(j = 1; j <= 4; ++j) {

			char p = 0;
			int mask = (1 << (j - 1));

			for(k = 1; k <= 12 ; ++k) {
				
				if( (k & mask) && (k != mask) )
					p = p ^ getBite(k + 4, r->payload[i], r->payload[i + 1]);
			}

			//printf("%d %d %d \n",j, mask, p);

			if(j == 4)
				setBite(&(r->payload[i + 1]), 4 , p);
			else 
				setBite(&(r->payload[i]), 4 + mask, p);
		}
	}

	r->len = 2 * r->len;
}


char construct_nr(char frst, char scd) {

	return  (getBite(7, frst, scd) << 7)
		  + (getBite(9, frst, scd) << 6)
	      + (getBite(10, frst, scd) << 5)
	      + (getBite(11, frst, scd) << 4)
	      + (getBite(13, frst, scd) << 3)
	      + (getBite(14, frst, scd) << 2)
	      + (getBite(15, frst, scd) << 1)
	      + (getBite(16, frst, scd) << 0);
}


void corectare(msg* r) {

	//schimbam mai intai bitii necesari

	int i; int j; int k;

	//printf("%d\n", r->len);

	for(i = 0 ; i < r->len; i += 2) {
		//printf("%d ", r->payload[i/2]);

		int pos = 0;//pozitia bitului modificat in urma transmiterii

		for(j = 1; j <= 4; ++j) {

			int mask = 1 << (j - 1);
			char p = 0;

			for(k = 1; k <= 12; ++k) {
				if(k & mask)
					p = p ^ getBite(k + 4, r->payload[i], r->payload[i + 1]);
			}

			if(p) 
				pos += mask;
		}

		

		if(pos)
			changeBite(pos + 4, &(r->payload[i]), &(r->payload[i + 1]));
	}

	//reconstruim numarul

	//printf("\n\n");

	for(i = 0 ; i < r->len; i += 2) {

		r->payload[i/2] = construct_nr(r->payload[i], r->payload[i + 1]);
		//printf("%d ", r->payload[i/2]);
	}

	r->len = r->len / 2;
}

int receive_message(msg* r, int mode) {

	int res = recv_message(r);
	int i; int j;

	if (res < 0) {
		perror("[RECEIVER] Receive error. Exiting.\n");
		return -1;
	}

	if(mode == simplu) return 1;

	if(mode == ACK) {

		printf("%d\n", r->len);

		if(send_ack(ACK) < 0)
			return -1;
		else 
			return 1;
	}


	if(mode == parity) {

		char par = 0;

	  	for(i = 1 ; i < r->len; ++i) {

	   	 	char c = r->payload[i];
	    	int mask = (1<<7);

	   		for(j = 0 ; j < 8 ; ++j) {

			    par = par ^ (mask & c);
			    mask >>= 1;
		    }
		}

		if(par != r->payload[0]) {
			if(send_ack(NACK) < 0)
				return -1;
		} else if(send_ack(ACK) < 0)
			return -1;
		
		strcpy(r->payload , r->payload + 1);
		r->len--;

		printf("%s\n", r->payload);

		return 1;
	}

	if(mode == hamming) {

		//corectam mesajul primit daca e nevoie

		printf("Inainte corectare: %s\n", r->payload);
		
		corectare(r);

		printf("Dupa corectare: %s\n", r->payload);

		if(send_ack(ACK) < 0)
			return -1;

		return 1;

	}

	return 1;
}

int send_mess(msg r,int mode) {

	int res; 
	int i; int j;

	if(mode == simplu) {
		
		res = send_message(&r);

		if (res < 0) {
			perror("[RECEIVER] Send error. Exiting.\n");
			return -1;
		}

		printf("%s\n", r.payload);

		return 1;
	}

	if(mode == ack) {

		res = send_message(&r);
		printf("%s\n", r.payload);


		if (res < 0) {
			perror("[RECEIVER] Send error. Exiting.\n");
			return -1;
		}
		
		if(rec_ack() < 0) 
			return -1;
		

		return 1;
	}


	if(mode == parity) {

		if(r.len >= MSGSIZE) {

			perror("[RECEIVER] Message too long. Exiting.\n");
			return -1;
		}

		char par = 0;

	  	for(i = 0 ; i < r.len ; ++i) {

	   	 	char c = r.payload[i];
	    	int mask = (1<<7);

	   		for(j = 0 ; j < 8 ; ++j) {

			    par = par ^ (mask & c);
			    mask >>= 1;
		    }
		}
		//fac loc pentru primul caracter
		strcpy(r.payload + 1, r.payload);
		r.payload[0] = par;
		r.len++;


		printf("%s\n", r.payload + 1);


		res = send_message(&r);

		if (res < 0) {
			perror("[RECEIVER] Send error. Exiting.\n");
			return -1;
		}
		
		if( (res = rec_ack()) < 0)
			return -1;

		if(res == NACK) {

			//recosntruiesc mesajul si il trimit din nou
			strcpy(r.payload, r.payload + 1);
			r.len--;

			printf("[RECEIVER] Retransmite. \n");
			send_mess(r, mode);
		}

		return 1;
	}


	if(mode == hamming) {

		if(r.len > MSGSIZE / 2) {
			perror("[RECEIVER] Mesagge too long. Exiting.\n");
			return -1;
		}

		printf("Ce vreau sa trimit: %s\n", r.payload);

		construct_hamming(&r);
		corectare(&r);

		printf("Ar trebuie sa obtin ce aveam inainte: %s\n", r.payload);
		construct_hamming(&r);

		res = send_message(&r);


		if (res < 0) {
			perror("[RECEIVER] Send error. Exiting.\n");
			return -1;
		}
		
		if(rec_ack() < 0) 
			return -1;

		return 1;
	}

	return 1;
}


int binary_search(msg* p, int mode) {

	msg r;

	int pos; int step;

	for(step = 1 ; step <= 500; step <<= 1);

	for(pos = 0; step; step >>= 1) {

		int nr_to_send = pos + step;

		if(nr_to_send >= 1000) 
			nr_to_send = 999;

		sprintf(p->payload, "%d", nr_to_send);

		if( send_mess(*p, mode) < 0 ) 			return -1;

		if(receive_message(&r, mode) < 0)		return -1;

		char first_char = r.payload[0];
		char second_char = r.payload[1];

		if(first_char == 'b' )  
			pos = pos + step;
		else if(second_char == 'u')
				return 1;
	}

	printf("[RECEIVER] Could not find the number. Exiting. \n");

	return 0;
}


int set_mode(int argc, char* argv[], int *mode) {

	if(argc == 1) {
		*mode = simplu;
		return 1;
	} else {

		if(strcmp(argv[1], "ack") == 0)		 *mode = ack;
		if(strcmp(argv[1], "parity") == 0)   *mode = parity;
		if(strcmp(argv[1], "hamming") == 0)  *mode = hamming;

		return 1;
	}

	printf("[RECEIVER] Invalid mode. Exit.\n");

	return -1;
}


int main(int argc, char *argv[])  {

	int mode;

	if( set_mode(argc, argv, &mode) < 0) return -1;

	msg r;	

	printf("%d\n", mode);
	
	printf("[RECEIVER] Starting.\n");

	init(HOST, PORT);

	if(receive_message(&r, mode) < 0) 	return -1;

	r.len = sprintf(r.payload, "Hello");
	if(send_mess(r, mode) < 0)			return -1;

	if(receive_message(&r, mode) < 0)		return -1;
	
	if(receive_message(&r, mode) < 0)		return -1;

	if(receive_message(&r, mode) < 0)		return -1;

	r.len = sprintf(r.payload, "YEY");
	if(send_mess(r, mode) < 0)			return -1;

	r.len = sprintf(r.payload, "OK");
	if(send_mess(r, mode) < 0)			return -1;

	if(receive_message(&r, mode) < 0)		return -1;

	msg p;

	if(binary_search(&p, mode) == 0)		return -1;

	p.len = sprintf(p.payload, "exit");
	
	if(receive_message(&r, mode) < 0)		return -1;

	if( send_mess(p, mode) < 0 ) 		    return -1;


	printf("[RECEIVER] Finished receiving..\n");

	return 0;
}
